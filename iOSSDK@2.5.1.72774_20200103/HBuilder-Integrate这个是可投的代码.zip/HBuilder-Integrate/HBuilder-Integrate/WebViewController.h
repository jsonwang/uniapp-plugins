//
//  NewViewController.h
//  HBuilder-Integrate
//
//  Created by EICAPITAN on 16/5/12.
//  Copyright © 2016年 DCloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PDRCore.h"
#import "PDRCoreAppWindow.h"
@interface WebViewController : UIViewController<PDRCoreDelegate,PDRCoreAppWindowDelegate>

@end
