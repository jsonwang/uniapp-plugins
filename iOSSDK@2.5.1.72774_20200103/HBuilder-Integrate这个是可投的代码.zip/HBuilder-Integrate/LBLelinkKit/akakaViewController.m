//
//  akakaViewController.m
//  HBuilder
//
//  Created by ak on 2020/2/19.
//  Copyright © 2020 DCloud. All rights reserved.
//

#import "akakaViewController.h"
#import "PDRToolSystem.h"
#import "PDRToolSystemEx.h"
#import "PDRCoreAppFrame.h"
#import "PDRCoreAppManager.h"
#import "PDRCoreAppWindow.h"
#import "PDRCoreAppInfo.h"
@interface akakaViewController ()
{
//    PDRCoreAppFrame* appFrame;
}

@end
 

@implementation akakaViewController

- (void)viewDidLoad
{
 
      self.view.backgroundColor = [UIColor yellowColor];
}

 

@end
