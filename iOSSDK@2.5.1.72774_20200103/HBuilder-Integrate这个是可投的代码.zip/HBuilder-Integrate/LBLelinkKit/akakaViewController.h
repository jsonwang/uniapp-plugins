//
//  akakaViewController.h
//  HBuilder
//
//  Created by ak on 2020/2/19.
//  Copyright © 2020 DCloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PDRCore.h"
#import "PDRCoreAppWindow.h"

NS_ASSUME_NONNULL_BEGIN

@interface akakaViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
