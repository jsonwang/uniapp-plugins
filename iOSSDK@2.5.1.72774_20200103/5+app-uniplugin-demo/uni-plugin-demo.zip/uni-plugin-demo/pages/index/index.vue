<template>
    <view>
        <button @click="pluginShow">PluginTestFunction</button>
		<button @click="pluginShowArrayArgu">PluginTestFunctionArrayArgu</button>
		<button @click="pluginGetString">PluginTestFunctionSync</button>
		<button @click="pluginGetStringArrayArgu">PluginTestFunctionSyncArrayArgu</button>
		
		   <button class="button" @click="beginScan">扫描设置</button>
		        <button class="button" @click="beginPlay">开2始投屏</button>

    </view>
</template>
<style>
	button {
		width: 94%;
		margin: 20upx auto;
	}
</style>
<script>
	
	
// 扩展的 js 文件的位置：common/plugins.js
var plugins = require('../../common/testplugin.js');
export default {
    data() {
        return {
            plugins: plugins
        };
    },
    methods: {
		
		beginScan(){
		    console.log(" 开始扫描设备");
			this.plugins.PluginTestFunction(
			    'Html51111111',
			    'Plus',
			    'AsyncFunction',
			    'MultiArgument!',
			    function(result) {
					console.log("111112222");
					uni.showToast({title:JSON.stringify(result),icon:'none'});
			    },
			    function(result) {
					console.log("3333444");
					uni.showToast({title:result});
			    }
			);
		  
		},
		beginPlay(){
		    console.log(" 开始投屏播放");
			
			const dcRichAlert = uni.requireNativePlugin('libleboak');
			
			
		  
		},
		
        pluginShow() {
			uni.showToast("柏慧燕都");
			
			console.log("this is running");
			 //引用方式  
			const dcRichAlert = uni.requireNativePlugin('DCloud-RichAlert');  
			
	 
			 //调用  
			dcRichAlert.show({  
			                    position: 'bottom',  
			                    title: "提示信息",  
			                    titleColor: '#FF0000',  
			                    content: "<a href='https://uniapp.dcloud.io/' value='Hello uni-app'>uni-app</a> 是一个使用 Vue.js 开发跨平台应用的前端框架!\n免费的\n免费的\n免费的\n重要的事情说三遍",  
			                    contentAlign: 'left',  
			                    checkBox: {  
			                        title: '不再提示',  
			                        isSelected: true  
			                    },  
			                    buttons: [{  
			                            title: '取消'  
			                        },  
			                        {  
			                            title: '否'  
			                        },  
			                        {  
			                            title: '确认',  
			                            color: '#3F51B5'  
			                        }  
			                    ]  
			                }, result => {  
			                    switch (result.type) {  
			                        case 'button':  
			                            console.log("callback---button--" + result.index);  
			                            break;  
			                        case 'checkBox':  
			                            console.log("callback---checkBox--" + result.isSelected);  
			                            break;  
			                        case 'a':  
			                            console.log("callback---a--" + JSON.stringify(result));  
			                            break;  
			                        case 'backCancel':  
			                            console.log("callback---backCancel--");  
			                            break;  
			                    }  
			                });
            this.plugins.PluginTestFunction(
                'Html51111111',
                'Plus',
                'AsyncFunction',
                'MultiArgument!',
                function(result) {
					console.log("111112222");
					uni.showToast({title:JSON.stringify(result),icon:'none'});
                },
                function(result) {
					console.log("3333444");
					uni.showToast({title:result});
                }
            );
        },
        pluginShowArrayArgu() {
            this.plugins.PluginTestFunctionArrayArgu(
                ['Html5', 'Plus', 'AsyncFunction', 'ArrayArgument!'],
                function(result) {
                    uni.showToast({title:result,icon:'none'});
                },
                function(result) {
                    uni.showToast({title:result,icon:'none'});
                }
            );
        },
        pluginGetString() {
			uni.showToast({title:this.plugins.PluginTestFunctionSync('Html5', 'Plus', 'SyncFunction', 'MultiArgument!'),icon:'none'});
        },
        pluginGetStringArrayArgu() {
            var Argus = this.plugins.PluginTestFunctionSyncArrayArgu([
                'Html5',
                'Plus',
                'SyncFunction',
                'ArrayArgument!'
            ]);
			uni.showToast({title:Argus.RetArgu1 + '_' + Argus.RetArgu2 + '_' + Argus.RetArgu3 + '_' + Argus.RetArgu4,icon:'none'});
        }
    }
};
</script>
<style>
</style>
